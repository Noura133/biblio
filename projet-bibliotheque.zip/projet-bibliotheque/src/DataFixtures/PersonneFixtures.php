<?php

namespace App\DataFixtures;

use App\Entity\Personne;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\Security\Core\User\UserInterface;

class PersonneFixtures extends Fixture
{


   /* private $encoder;

    public function __construct(UserPasswordEncoderInterface $encoder)
    {
        $this->encoder = $encoder;
    }*/

    public function load(ObjectManager $manager)
    {
        // $product = new Product();
        // $manager->persist($product);

        

        $Personne1= new Personne();
        $Personne1->setCin('09568542');
        $Personne1->setNom('Noura');
        $Personne1->setPrenom('Hfaiedh');
        $Personne1->setAdress('sousse, riadh');
        $Personne1->setEmail('noura@gmail.com');
       // $MDP = $this->encoder->encodePassword($Personne1, 'pass_1234');
        $Personne1->setMDP('noura123');
       
        

        $Personne2= new Personne();
        $Personne2->setCin('12365842');
        $Personne2->setNom('eya');
        $Personne2->setPrenom('kouailia');
        $Personne2->setAdress('sousse, riadh');
        $Personne2->setEmail('eya@gmail.com');
       // $MDP = $this->encoder->encodePassword($Personne2, 'pass_1324');
        $Personne2->setMDP('eya123');
      
       

        $manager->persist($Personne1);
        $manager->persist($Personne2);
        


        $manager->flush();


        
    }
     /**
     * @return array
     */
    public function getDependencies(): array
    {
        return [
            CategorieFixtures::class,
        ];
    }
}