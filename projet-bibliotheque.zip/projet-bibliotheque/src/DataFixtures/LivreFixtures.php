<?php

namespace App\DataFixtures;

use App\Entity\Livre;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class LivreFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        // $product = new Product();
        // $manager->persist($product);
        for ($i = 100; $i <= 130; $i++){
            $LivreRomance1= new Livre();
            $LivreRomance1->setNomLivre('Madame Bovary');
            $LivreRomance1->setDateEdition('16/05/2001');
            $LivreRomance1->setLibCategorie($manager->merge($this->getReference('category-Romance')));
            $LivreRomance1->setAuteur('gostave flaubert');
            $LivreRomance1->setDescription('C est l histoire d une femme mal mariée de son médiocre époux de ses amants égoïstes et vains de ses rêves de ses chimères de sa mort. C est l histoire d une province étroite dévote et bourgeoise. C est aussi l histoire du roman français. Rien dans ce tableau, n avait de quoi choquer la société du Second Empire. Mais nexorable comme une tragédie lamboyant comme un drame mordant comme une comédie le livre s etait donné une arme redoutable : le style. Pour ce vrai crime, Flaubert se retrouva en correctionnel.
            Aucun roman n est innocent : celui-à moins qu un autre. Lire Madame Bovary, au XXIe siècle, c est affronter le scandale que représente une œuvre aussi sincère qu impérieuse. Dans chacune de ses phrases, Flaubert a versé une dose de cet arsenic dont Emma Bovary s empoisonne : c est un livre offensif, corrosif, dont l ironie outrage toutes nos valeurs, et la littérature même, qui ne s en est jamais vraiment remise.');
            $LivreRomance1->setImage('image1.gif');
            $LivreRomance1->setDisponible(true);
    
            $LivreRomance2= new Livre();
            $LivreRomance2->setNomLivre('Rebecca');
            $LivreRomance2->setDateEdition('06/04/1971');
            $LivreRomance2->setLibCategorie($manager->merge($this->getReference('category-Romance')));
            $LivreRomance2->setAuteur('Daphne Du Maurier');
            $LivreRomance2->setDescription('Un manoir majestueux : Manderley. Un an après sa mort, le charme noir de l’ancienne propriétaire, Rebecca de Winter, hante encore le domaine et ses habitants. La nouvelle épouse, jeune et timide, de Maxim de Winter pourra-t-elle échapper à cette ombre, à son souvenir ?
            Immortalisé au cinéma par Hitchcock en 1940, le chef-d’œuvre de Daphné du Maurier a fasciné plus de trente millions de lecteurs à travers le monde. Il fait aujourd’hui l’objet d’une traduction inédite qui a su restituer toute la puissance dévocation du texte originel et en révéler la noirceur.
            .');
            $LivreRomance2->setImage('image2.gif');
            $LivreRomance2->setDisponible(true);
          
    
            $LivreRomance3= new Livre();
            $LivreRomance3->setNomLivre('la Dame aux camélias');
            $LivreRomance3->setDateEdition('01/01/1975');
            $LivreRomance3->setLibCategorie($manager->merge($this->getReference('category-Romance')));
            $LivreRomance3->setAuteur('Alexandre demas fils');
            $LivreRomance3->setDescription('la société bourgeoise du XIXe siècle tolérait qu un homme puisse entretenir une liaison, aussi ruineuse fût-elle, avec une courtisane, mais en aucun cas il ne devait s eprendre d une de ces demi-mondaines. C est pourtant ce qui arrive à Armand Duval, qui aime dès le premier regard la plus luxueuse d entre toutes, la séduisante et capricieuse Marguerite Gautier. Il confie à un inconnu compatissant cette passion tragique, à l occasion de la mise en vente des biens de la jeune femme, emportée par la tuberculose : après les premières rebuffades, la belle croqueuse de fortunes l élit comme amant de cœur, sensible à la sincérité de son amour, si différent en cela des amitiés intéressées qui l entourent. Suivront les intermittences de la douleur, les rares moments de bonheur, la fulgurance de la souffrance puis la vengeance destructrice');
            $LivreRomance3->setImage('image3.gif');
            $LivreRomance3->setDisponible(false);
    
            $LivreAventure1= new Livre();
            $LivreAventure1->setNomLivre('la mort en arabie');
            $LivreAventure1->setDateEdition('10/01/2002');
            $LivreAventure1->setLibCategorie($manager->merge($this->getReference('category-Aventure')));
            $LivreAventure1->setAuteur('Thorkild hansen');
            $LivreAventure1->setDescription('Janvier 1761 : cinq Européens s embarquent de Copenhague pour Constantinople. De là, ils gagnent Alexandrie et Suez, puis traversent la mer Rouge. Leur but ultime : un pays inviolé- le Yémen, qu à l époque on appelle encore l Arabie Heureuse. Tel est le point de départ d une aventure aux multiples péripéties scientifiques et dramatiques. Deux siècles plus tard, se guidant sur les documents laissés par les membres de l expédition, Thorkild Hansen suit leurs traces. Et il écrit un immense récit de quête, d espérance et de mort, qui s impose aussitôt, au Danemark, puis à travers l Europe, comme un chef-d œuvre.');
            $LivreAventure1->setImage('image4.gif');
            $LivreAventure1->setDisponible(true);
    
            $LivreAventure2= new Livre();
            $LivreAventure2->setNomLivre('le maitre de ballantrae');
            $LivreAventure2->setDateEdition('23/06/2000');
            $LivreAventure2->setLibCategorie($manager->merge($this->getReference('category-Aventure')));
            $LivreAventure2->setAuteur('Robert louis stevenson');
            $LivreAventure2->setDescription('Le Maître de Ballantrae (1889) est le chef-d oeuvre de Stevenson. Ce roman d aventures, qui commence en Ecosse en 1745, entraîne le lecteur sur les champs de bataille, sur les mers avec les pirates, vers les Indes orientales et enfin en Amérique du Nord avec sa terrible forêt sauvage, hantée par des trafiquants, des aventuriers patibulaires et des Indiens sur le sentier de la guerre.');
            $LivreAventure2->setImage('image5.gif');
            $LivreAventure2->setDisponible(true);
         
    
            $LivreAventure3= new Livre();
            $LivreAventure3->setNomLivre('le tour du monde en quatre vingts jours');
            $LivreAventure3->setDateEdition('01/03/1976');
            $LivreAventure3->setLibCategorie($manager->merge($this->getReference('category-Aventure')));
            $LivreAventure3->setAuteur('jules verne');
            $LivreAventure3->setDescription('Balivernes editions,jusqu à 5 ans,
            Phileas Fogg parie la moitié de sa fortune avec ses amis qu’il réussira à faire le tour du monde en quatre-vingts jours ! Le soir-même, il part avec son valet Passepartout dans un périple qui le mènera de Paris et d’Italie en Inde (où ils sauveront la belle Aouda), au Japon, aux Etats-Unis aussi bien en bateau qu’en train et même à dos d’éléphant ! Mais pendant ce temps, l’inspecteur Fix le poursuit et voudrait l’arrêter car il pense que Phileas est un voleur… Seront-ils de retour à temps à Londres malgré les embuches ?
            ');
            $LivreAventure3->setImage('image6.gif');
            $LivreAventure3->setDisponible(false);
    
    
            $LivreBiographie1=new Livre();
            $LivreBiographie1->setNomLivre('la petite femelle');
            $LivreBiographie1->setDateEdition('20/08/2015');
            $LivreBiographie1->setLibCategorie($manager->merge($this->getReference('category-Biographie')));
            $LivreBiographie1->setAuteur('philippe jaenada');
            $LivreBiographie1->setDescription('Au mois de novembre 1953 débute le procès retentissant de Pauline Dubuisson, accusée d avoir tué de sang-froid son amant. Mais qui est donc cette beauté ravageuse dont la France entière réclame la tête ? Une arriviste froide et calculatrice ? Un monstre de duplicité qui a couché avec les Allemands, a été tondue, avant d assassiner par jalousie un garçon de bonne famille ? Ou n est-elle, au contraire, qu une jeune fille libre qui revendique avant l heure son émancipation et questionne la place des femmes au sein de la société ? Personne n a jamais voulu écouter ce qu elle avait à dire, elle que les soubresauts de l Histoire ont pourtant broyée sans pitié');
            $LivreBiographie1->setImage('image7.gif');
            $LivreBiographie1->setDisponible(false);
    
            $LivreBiographie2=new Livre();
            $LivreBiographie2->setNomLivre('Secret shadow');
            $LivreBiographie2->setDateEdition('07/04/2020');
            $LivreBiographie2->setLibCategorie($manager->merge($this->getReference('category-Biographie')));
            $LivreBiographie2->setAuteur('Daniel ghost');
            $LivreBiographie2->setDescription('Secret Shadow est un roman biographique des plus prenants, inspiré de faits réels se déroulant des années 80 à nos jours.
            Des tournures inattendues, empreintes d’émotions fortes, vont changer à jamais la vie d’un petit garçon encore ordinaire.
            Aucun mensonge, aussi cruelle soit la vérité ! Un héros pour certains, un monstre pour d’autres, c’est à vous de juger. Je ne fais que narrer le parcours émouvant de ce garçon devenu le Ghost, l’une des personnes les plus dangereuses de ce monde.
            Je suis le Ghost, matricule 013, au service de Secret Shadow. Ce qui suit est mon histoire…');
            $LivreBiographie2->setImage('image8.gif');
            $LivreBiographie2->setDisponible(false);
            
    
            $LivreBiographie3=new Livre();
            $LivreBiographie3->setNomLivre('le beau temps');
            $LivreBiographie3->setDateEdition('20/08/2015');
            $LivreBiographie3->setLibCategorie($manager->merge($this->getReference('category-Biographie')));
            $LivreBiographie3->setAuteur('Maryline desbiolles');
            $LivreBiographie3->setDescription('Maurice Jaubert, né à Nice en 1900, compositeur connu avant tout pour ses musiques de films, meurt en juin 1940 sur le front. Dans ce roman biographique qui est presque une lettre d’amour, Maryline Desbiolles, devenue niçoise, retrace la vie de cet être généreux et créatif, qui aura fréquenté les formes nouvelles de l’art, en musique (il côtoie Honegger et Messiaen) et au cinéma (il travaille avec René Clair, Marcel Carné, Jean Renoir dont il connaît bien la famille, et surtout Jean Vigo). À travers ces quarante ans d’une vie menée tambour battant, on plonge dans l’effervescence artistique des années 20 et 30, à Paris où Jaubert est allé exercer ses talents (en particulier à la salle Pleyel), mais tout autant à Nice, ville cosmopolite traversée et réveillée par toutes les avant-gardes.
            Maryline Desbiolles ressuscite avec ferveur ce créateur passionnant et méconnu, dans un livre d’atmosphère, où le beau temps peut cacher bien des orages.');
            $LivreBiographie3->setImage('image9.gif');
            $LivreBiographie3->setDisponible(true);
    
            $LivreBiographie4=new Livre();
            $LivreBiographie4->setNomLivre('La claire fontaine');
            $LivreBiographie4->setDateEdition('22/08/2013');
            $LivreBiographie4->setLibCategorie($manager->merge($this->getReference('category-Biographie')));
            $LivreBiographie4->setAuteur('David bosc');
            $LivreBiographie4->setDescription('L’homme qui venait de franchir la frontière, ce 23 juillet 1873, était un homme mort et la police n’en savait rien. Mort aux menaces, aux chantages, aux manigances. Un homme mort qui allait faire l’amour avant huit jours.
            En exil en Suisse, Gustave Courbet s’est adonné aux plus grands plaisirs de sa vie : il a peint, il a fait la noce, il s’est baigné dans les rivières et dans les lacs. On s’émerveille de la liberté de ce corps dont le sillage dénoue les ruelles du bourg, de ce gros ventre qui ouvre lentement les eaux, les vallons, les bois.
            Quand il peignait, Courbet plongeait son visage dans la nature, les yeux, les lèvres, le nez, les deux mains, au risque de s’égarer, au risque surtout d’être ébloui, soulevé, délivré de lui-même.');
            $LivreBiographie4->setImage('image10.gif');
            $LivreBiographie4->setDisponible(true);
        
        $manager->persist($LivreRomance1);
        $manager->persist($LivreRomance2);
        $manager->persist($LivreRomance3);
        $manager->persist($LivreAventure1);
        $manager->persist($LivreAventure2);
        $manager->persist($LivreAventure3);
        $manager->persist($LivreBiographie1);
        $manager->persist($LivreBiographie2);
        $manager->persist($LivreBiographie3);
        $manager->persist($LivreBiographie4);

    }

        $manager->flush();


        
    }
     /**
     * @return array
     */
    public function getDependencies(): array
    {
        return [
            CategorieFixtures::class,
        ];
    }
}
