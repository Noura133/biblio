<?php

namespace App\Entity;

use App\Repository\LivreRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=LivreRepository::class)
 */
class Livre
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nomLivre;
/**
     * @ORM\Column(type="string", length=255)
     */
    private $DateEdition;

    /**
     * @ORM\ManyToOne(targetEntity=Categorie::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $libCategorie;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $auteur;

    /**
     * @ORM\ManyToOne(targetEntity=Reservation::class, inversedBy="nomLivre")
     * @ORM\JoinColumn(nullable=true)
     */
    private $no;
    /**
     * @ORM\Column(type="text")
     */
    private $description;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $images;

     /**
     * @ORM\Column(type="boolean")
     */
    private $disponible;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNomLivre(): ?string
    {
        return $this->nomLivre;
    }

    public function setNomLivre(string $nomLivre): self
    {
        $this->nomLivre = $nomLivre;

        return $this;
    }


    public function __toString()
    {
        return $this->getNomLivre();
    }

    public function getDateEdition(): ?string
    {
        return $this->DateEdition;
    }

    public function setDateEdition(string $DateEdition): self
    {
        $this->DateEdition = $DateEdition;

        return $this;
    }

    public function getLibCategorie(): ?Categorie
    {
        return $this->libCategorie;
    }

    public function setLibCategorie(?Categorie $libCategorie): self
    {
        $this->libCategorie = $libCategorie;

        return $this;
    }

    public function getAuteur(): ?string
    {
        return $this->auteur;
    }

    public function setAuteur(string $auteur): self
    {
        $this->auteur = $auteur;

        return $this;
    }

    public function getNo(): ?Reservation
    {
        return $this->no;
    }

    public function setNo(?Reservation $no): self
    {
        $this->no = $no;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }
    public function getImage(): ?string
    {
        return $this->image;
    }

    public function setImage(?string $image): self
    {
        $this->image = $image;

        return $this;
    }

    public function getDisponible(): ?bool
    {
        return $this->disponible;
    }

    public function setDisponible(bool $disponible): self
    {
        $this->disponible= $disponible;

        return $this;
    }
}
