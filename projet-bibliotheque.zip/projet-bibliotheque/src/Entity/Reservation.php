<?php

namespace App\Entity;

use App\Repository\ReservationRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ReservationRepository::class)
 */
class Reservation
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\OneToMany(targetEntity=Livre::class, mappedBy="no")
     */
    private $nomLivre;

    /**
     * @ORM\Column(type="date")
     */
    private $dateReservation;

    /**
     * @ORM\Column(type="date", nullable=true)
     */
    private $dateAnnulation;

    /**
     * @ORM\ManyToOne(targetEntity=Profil::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $cin;

    public function __construct()
    {
        $this->nomLivre = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }


    /**
     * @return Collection|Livre[]
     */
    public function getNomLivre(): Collection
    {
        return $this->nomLivre;
    }
    public function setNomLivre(string $nomLivre): self
    {
        $this->nomLivre = $nomLivre;

        return $this;
    }
    
    /*public function addNomLivre(Livre $nomLivre): self
    {
        if (!$this->nomLivre->contains($nomLivre)) {
            $this->nomLivre[] = $nomLivre;
            $nomLivre->setNo($this);
        }

        return $this;
    }*/

    /*public function removeNomLivre(Livre $nomLivre): self
    {
        if ($this->nomLivre->removeElement($nomLivre)) {
            // set the owning side to null (unless already changed)
            if ($nomLivre->getNo() === $this) {
                $nomLivre->setNo(null);
            }
        }

        return $this;
    }*/

    public function getDateReservation(): ?\DateTimeInterface
    {
        return $this->dateReservation;
    }

    public function setDateReservation(\DateTimeInterface $dateReservation): self
    {
        $this->dateReservation = $dateReservation;

        return $this;
    }

    public function getDateAnnulation(): ?\DateTimeInterface
    {
        return $this->dateAnnulation;
    }

    public function setDateAnnulation(?\DateTimeInterface $dateAnnulation): self
    {
        $this->dateAnnulation = $dateAnnulation;

        return $this;
    }

    public function getCin(): ?Profil
    {
        return $this->cin;
    }

    public function setCin(?Profil $cin): self
    {
        $this->cin = $cin;

        return $this;
    }
}
