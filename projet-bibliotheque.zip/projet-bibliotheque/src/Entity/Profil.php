<?php

namespace App\Entity;

use App\Repository\ProfilRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ProfilRepository::class)
 */
class Profil
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\OneToOne(targetEntity=Personne::class, inversedBy="pseudonyme", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $cin;

    /**
     * @ORM\OneToOne(targetEntity=Personne::class, cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $nom;

    /**
     * @ORM\OneToOne(targetEntity=Personne::class, cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $prenom;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $nbLivreReserver;

    /**
     * @ORM\OneToMany(targetEntity=Reservation::class, mappedBy="no")
     */
    private $nomLivre;


  

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCin(): ?Personne
    {
        return $this->cin;
    }

    public function setCin(Personne $cin): self
    {
        $this->cin = $cin;

        return $this;
    }

    public function getNom(): ?Personne
    {
        return $this->nom;
    }

    public function setNom(Personne $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?Personne
    {
        return $this->prenom;
    }

    public function setPrenom(Personne $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getNbLivreReserver(): ?int
    {
        return $this->nbLivreReserver;
    }

    public function setNbLivreReserver(?int $nbLivreReserver): self
    {
        $this->nbLivreReserver = $nbLivreReserver;

        return $this;
    }

    public function getNomLivre(): ?string
    {
        return $this->nomLivre;
    }

    public function setNomLivre(string $nomLivre): self
    {
        $this->nomLivre = $nomLivre;

        return $this;
    }
}
