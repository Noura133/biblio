<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Reservation;
use App\Form\ReservationType;
use Symfony\Component\HttpFoundation\Request;


class ReservationController extends AbstractController
{
    /**
     * @Route("/reservation", name="reservation")
     */
    public function index(): Response
    {
        return $this->render('reservation/index.html.twig', [
            'controller_name' => 'ReservationController',
        ]);
    } 
    /**
    * Creates a new reservation entity.
    *
    * @Route("/reservation/create", name="reservation.create", methods="GET")
    *
    *
    *
    * @param Request $request
    * @param EntityManagerInterface $em
    *
    * @return RedirectResponse|Response
    */
   public function create(Request $request, EntityManagerInterface $em) : Response
   {
       $reservation = new Reservation();
       $form = $this->createForm(ReservationType::class, $reservation);
       $form->handleRequest($request);

       if ($form->isSubmitted() && $form->isValid()) {
           $em->persist($reservation);
           $em->flush();

           return $this->redirectToRoute('livre.list');
       }

       return $this->render('reservation/create.html.twig', [
           'form' => $form->createView(),
       ]);
   }
   
}
