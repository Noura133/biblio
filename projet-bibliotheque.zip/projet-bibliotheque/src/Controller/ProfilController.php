<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Profil;
use App\Repository\ProfilRepository;


class ProfilController extends AbstractController
{
    /**
     * @Route("/profil", name="profil")
     */
    public function index(): Response
    {
        return $this->render('profil/index.html.twig', [
            'controller_name' => 'ProfilController',
        ]);
    }

     /**
     * Lists all profils entities.
     *
     * @Route("/profil/list", name="profil.list")
     *@param ProfilRepository $l
     * @return Response
     */
    public function list(ProfilRepository $l) : Response
    {
        $Profils = $l->findActivebooks();//changer par findall() pour afficher meme les livre reserver

        return $this->render('profil/list.html.twig', [
            'profils' => $Profils,
        ]);
    }



   
}
