<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210101114037 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE categorie (id INT AUTO_INCREMENT NOT NULL, libelle VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE livre (id INT AUTO_INCREMENT NOT NULL, lib_categorie_id INT NOT NULL, no_id INT NOT NULL, nom_livre VARCHAR(255) NOT NULL, date_edition DATE NOT NULL, auteur VARCHAR(255) NOT NULL, INDEX IDX_AC634F99C2FDCF14 (lib_categorie_id), INDEX IDX_AC634F991A65C546 (no_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE personne (id INT AUTO_INCREMENT NOT NULL, cin VARCHAR(8) NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, adress VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, mdp VARCHAR(10) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE profil (id INT AUTO_INCREMENT NOT NULL, cin_id INT NOT NULL, nom_id INT NOT NULL, prenom_id INT NOT NULL, nb_livre_reserver INT DEFAULT NULL, UNIQUE INDEX UNIQ_E6D6B297E9795579 (cin_id), UNIQUE INDEX UNIQ_E6D6B297C8121CE9 (nom_id), UNIQUE INDEX UNIQ_E6D6B29758819F9E (prenom_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE reservation (id INT AUTO_INCREMENT NOT NULL, cin_id INT NOT NULL, date_reservation DATE NOT NULL, date_annulation DATE DEFAULT NULL, INDEX IDX_42C84955E9795579 (cin_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE livre ADD CONSTRAINT FK_AC634F99C2FDCF14 FOREIGN KEY (lib_categorie_id) REFERENCES categorie (id)');
        $this->addSql('ALTER TABLE livre ADD CONSTRAINT FK_AC634F991A65C546 FOREIGN KEY (no_id) REFERENCES reservation (id)');
        $this->addSql('ALTER TABLE profil ADD CONSTRAINT FK_E6D6B297E9795579 FOREIGN KEY (cin_id) REFERENCES personne (id)');
        $this->addSql('ALTER TABLE profil ADD CONSTRAINT FK_E6D6B297C8121CE9 FOREIGN KEY (nom_id) REFERENCES personne (id)');
        $this->addSql('ALTER TABLE profil ADD CONSTRAINT FK_E6D6B29758819F9E FOREIGN KEY (prenom_id) REFERENCES personne (id)');
        $this->addSql('ALTER TABLE reservation ADD CONSTRAINT FK_42C84955E9795579 FOREIGN KEY (cin_id) REFERENCES profil (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE livre DROP FOREIGN KEY FK_AC634F99C2FDCF14');
        $this->addSql('ALTER TABLE profil DROP FOREIGN KEY FK_E6D6B297E9795579');
        $this->addSql('ALTER TABLE profil DROP FOREIGN KEY FK_E6D6B297C8121CE9');
        $this->addSql('ALTER TABLE profil DROP FOREIGN KEY FK_E6D6B29758819F9E');
        $this->addSql('ALTER TABLE reservation DROP FOREIGN KEY FK_42C84955E9795579');
        $this->addSql('ALTER TABLE livre DROP FOREIGN KEY FK_AC634F991A65C546');
        $this->addSql('DROP TABLE categorie');
        $this->addSql('DROP TABLE livre');
        $this->addSql('DROP TABLE personne');
        $this->addSql('DROP TABLE profil');
        $this->addSql('DROP TABLE reservation');
    }
}
